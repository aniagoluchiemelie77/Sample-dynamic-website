<?php

namespace Stichoza\GoogleTranslate\Exceptions;

use ErrorException;

class LanguagesRequestException extends ErrorException
{
    //
}
