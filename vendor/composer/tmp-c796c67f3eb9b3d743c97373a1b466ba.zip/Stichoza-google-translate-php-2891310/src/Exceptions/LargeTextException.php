<?php

namespace Stichoza\GoogleTranslate\Exceptions;

use ErrorException;

class LargeTextException extends ErrorException
{
    //
}
