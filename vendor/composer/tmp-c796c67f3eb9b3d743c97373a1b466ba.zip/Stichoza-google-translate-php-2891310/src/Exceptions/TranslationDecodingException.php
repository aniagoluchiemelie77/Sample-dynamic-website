<?php

namespace Stichoza\GoogleTranslate\Exceptions;

use UnexpectedValueException;

class TranslationDecodingException extends UnexpectedValueException
{
    //
}
