<?php

namespace Stichoza\GoogleTranslate\Exceptions;

use ErrorException;

class TranslationRequestException extends ErrorException
{
    //
}
